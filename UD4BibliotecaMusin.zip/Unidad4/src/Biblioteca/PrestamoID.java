package Biblioteca;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

public class PrestamoID {
	@Column(nullable = true)
	private Date fechape;
	@ManyToOne
	@JoinColumn(name = "socio", referencedColumnName = "id", nullable = false)
	private Socio socio;
	@ManyToOne
	@JoinColumn(name = "libro", referencedColumnName = "isbn", nullable = false)
	private Libro libro;

	public PrestamoID() {

	}

	public PrestamoID(Date d, Socio socio, Libro libro) {
		this.socio = socio;
		this.libro = libro;
		this.fechape = d;
	}

	public Socio getSocio() {
		return socio;
	}

	public void setSocio(Socio socio) {
		this.socio = socio;
	}

	public Libro getLibro() {
		return libro;
	}

	public void setLibro(Libro libro) {
		this.libro = libro;
	}

	public Date getFechape() {
		return fechape;
	}

	public void setFechape(Date fechape) {
		this.fechape = fechape;
	}

}
