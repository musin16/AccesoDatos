package Examen;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Principal {

	public static Scanner t = new Scanner(System.in);
	public static Modelo bd = new Modelo();
	public static SimpleDateFormat formato = new SimpleDateFormat("ddMMyy");
	public static Empleado user = null;

	public static void main(String[] args) {

		if (bd.getConexion() != null) {
			int opcion = 0;
			do {
				System.out.println("Selecciona una opción");
				System.out.println("0-Salir");
				System.out.println("1-Crear Empleado");
				System.out.println("2-Enviar Mensaje");
				System.out.println("3-Leer mensajes y borrar");
				System.out.println("4-Estadistica mensajes");
				System.out.println("5-Identificarse");

				opcion = t.nextInt();
				t.nextLine();
				switch (opcion) {
				case 1:
					crearEmpleado();
					break;
				case 5:
					identificarse();
					break;
				case 2:
					enviarMensaje();
					break;
				case 3:
					leerMensajeBorrar();
					break;
				case 4:
					estadisticasMensajes();
					break;

				}

			} while (opcion != 0);
		} else {
			System.out.println("Error de conexión");
		}

	}

	private static void identificarse() {
		// TODO Auto-generated method stub
		System.out.println("Introduce el DNI: ");
		String dniIntro = t.nextLine();
		user = bd.buscarEmpleado(dniIntro);
		if (user != null) {
			System.out.println("Se ha registrado!!");
		} else {

			System.out.println("Error empleado no existe");
		}
	}

	private static void estadisticasMensajes() {
		// TODO Auto-generated method stub
		if (user != null) {

			ArrayList<Object[]> valores = bd.obtenerEstadistica(user);
	        for (Object[] obj : valores) {
	            System.out.println("NombreDepartameto : " + obj[0]);
	            System.out.println("Nº MesajesEnviados : " + obj[1]);
	            System.out.println("FechaPrimerMensaje : " + obj[2]);
	            System.out.println("FechaÚltimoMensaje : " + obj[3]);
	            
	        }


		} else {
			System.out.println("Error, debe identificarse primero");
		}
	}

	private static void leerMensajeBorrar() {
		// TODO Auto-generated method stub
		if (user != null) {

			mostrarMensajesEmpleado(user);

			if (bd.borrarMensajesEmpleado(user)) {
				System.out.println("Se han borrado correctamente los mensajes");
			} else {
				System.out.println("Error al borrar mensajes");
			}

		} else {
			System.out.println("Error, debe identificarse primero");
		}
	}

	private static void mostrarMensajesEmpleado(Empleado user) {
		// TODO Auto-generated method stub
		ArrayList<Mensaje> listaMensajes = bd.obtenerMensajes(user);
		for (Mensaje m : listaMensajes) {
			System.out.println(m);
		}
	}

	private static void enviarMensaje() {
		// TODO Auto-generated method stub

		if (user != null) {

			System.out.println("Introduce el departamento al que se va a enviar: ");
			String depIntro = t.nextLine();
			ArrayList<Destinatario> listaDestinatarios = bd.obtenerDestinatarios(depIntro);
			if (!listaDestinatarios.isEmpty()) {
				System.out.println("Introduce el asunto: ");
				String asunto = t.nextLine();
				System.out.println("Introduce el mensaje: ");
				String mensaje = t.nextLine();
				Date fecha = new Date();

				Mensaje m = new Mensaje(bd.obtenerUltimoIdMensaje(), user.getDni(), depIntro, fecha, asunto, mensaje,
						listaDestinatarios);

				if (bd.insertarMensaje(m)) {
					System.out.println("Correcto");
				} else {
					System.out.println("Error al insertar mensaje");
				}

			} else {

			}

		} else {
			System.out.println("Error, debe identificarse primero");
		}

	}

	private static void crearEmpleado() {
		// TODO Auto-generated method stub

		System.out.println("Introduce el dni: ");
		String dniIntro = t.nextLine();
		Empleado emp = bd.buscarEmpleado(dniIntro);
		if (emp == null) {
			System.out.println("Introduce el nombre: ");
			String nomIntro = t.nextLine();
			System.out.println("Introduce el departamento: ");
			String depIntro = t.nextLine();
			emp = new Empleado();
			emp.setDni(dniIntro);
			emp.setNombre(nomIntro);
			emp.setDepartamento(depIntro);
			if (bd.crearEmpleado(emp)) {
				System.out.println("Se ha creado el empleado");
			} else {
				System.out.println("Error al crear el empleado");
			}

		} else {
			System.out.println("Error, ya existe un empleado con ese dni");
		}

	}

}
