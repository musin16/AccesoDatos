package Examen;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table
public class Clase2 {
	public Clase2() {
		// TODO Auto-generated constructor stub
	}
}
