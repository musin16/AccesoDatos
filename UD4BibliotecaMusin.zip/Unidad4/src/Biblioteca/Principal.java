package Biblioteca;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Principal {
	public static Scanner sc = new Scanner(System.in);
	public static Modelo bd = new Modelo();
	public static SimpleDateFormat formato = new SimpleDateFormat("yyyyMMddHHmmss");

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (bd.getConexion() != null) {
			int opcion = 0;
			do {
				System.out.println("Selecciona una opción");
				System.out.println("0-Salir");
				System.out.println("1-Crear Prestamo");
				System.out.println("2-Mostrar prestamos de un socio");
				System.out.println("3-Devolver libro");
				System.out.println("4-Borrar Libro");
				opcion = sc.nextInt();
				sc.nextLine();

				switch (opcion) {
				case 1:
					crearPrestamo();
					break;
				case 2:
					mostrarPrestamosSocio();
					break;
				case 3:
					devolverLibroPrestado();
					break;
				case 4:
					borrarLibro();
					break;
				}

			} while (opcion != 0);
			bd.cerrar();
		} else {
			System.out.println("Error no hay conexión");
		}
	}

	private static void borrarLibro() {
		mostrarLibros();
		System.out.println("Introduce un isb:");
		Libro l = bd.obtenerLibro(sc.nextLine());
		if (l != null) {
			if (l.getPrestamos().size() == 0) {
				if (bd.borrarLibro(l)) {
					System.out.println("Se ha borrado el libro correctamente");
				} else {
					System.out.println("Error al borrar el libro");
				}
			} else {
				System.out.println("Queires borrar los prestamos y el libro?0 (No)/1(si)");
				String opcion = sc.nextLine();
				if (opcion.equalsIgnoreCase("1")) {
					if (bd.borrarLibroPrestamo(l)) {
						System.out.println("Se ha borrado el libro correctamente JUNTO CON SUS PRESTAMOS");
					} else {
						System.out.println("Error al borrar el libro Y SUS PRESTAMOS");
					}
				} else {
					System.out.println("No se ha borrado el libro ");
				}
			}
		} else {
			System.out.println("No existe  el libro");
		}
	}

	private static void devolverLibroPrestado() {
		try {
			mostrarLibros();
			System.out.println("Introduce el id de un socio: ");
			int id = sc.nextInt();
			sc.nextLine();
			Socio s = bd.obtenerSocio(id);
			if (s != null) {
				System.out.println();
				for (Prestamo pres : s.getPrestamos()) {
					if (pres.getFechaDevolReal() == null) {
						System.out.println(pres);
					}
				}
				System.out.println("Introduce el isbn del libro prestado: ");
				String isb = sc.nextLine();
				Libro l = bd.obtenerLibro(isb);
				if (l != null) {
					PrestamoID pd = new PrestamoID(new Date(), s, l);
					Prestamo pm = bd.obtenerPrestamo(pd);
					if (pm != null) {
						System.out.println("Prestamo encontrado");
						System.out.println(pm);
						if (pm.getFechaDevolReal() == null) {

							if (bd.devolverLibro(pm, s)) {
								System.out.println("Libr devuelto correctamente");
							} else {
								System.out.println("Error al devolver el libro");
							}
						} else {
							System.out.println("Devolucion se ha realizado");
						}
						/*
						 * Si el préstamo existe para el socio seleccionado y no está devuelto, se
						 * realizará la devolución. En caso contrario se informará del error.
						 */
					} else {
						System.out.println("Error no existe prestamo");
					}
				} else {
					System.out.println("El libro no existe");
				}
			} else {
				System.out.println("No existe el socio");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void mostrarPrestamosSocio() {
		System.out.println("Introduce el id de un socio: ");
		int id = sc.nextInt();
		sc.nextLine();
		Socio s = bd.obtenerSocio(id);
		if (s != null) {
			int cont = 0;
			for (Prestamo soc : s.getPrestamos()) {
				Date d = new Date();
				String fecha = "";
				if (soc.getFechaDevolReal() == null) {
					fecha = "pendiente";
					cont++;
				} else {
					fecha = d.toString();
				}
				System.out.println("Fecha prestamo: " + soc.getClave().getFechape() + " Fecha devolucion pevista: "
						+ soc.getFechaDevolPrevista() + "\nFecha devolucion real: " + fecha + "\nLibro : ISBN "
						+ soc.getClave().getLibro().getIsbn() + "\nTITULO: " + soc.getClave().getLibro().getTitulo());
			}
			System.out.println("Numero total de prestamos: " + s.getPrestamos().size());
			System.out.println("Numero total de prestamos pendientes: " + cont);
		} else {
			System.out.println("Error no existe el socio o no tiene prestamos");
		}
//Se debe informar del número de préstamos totales del socio y del nº de préstamos pendientes.
	}

	private static void crearPrestamo() {
		mostrarSocios();
		try {
			System.out.println("Introduce el codigo de socio: ");
			int id = sc.nextInt();
			sc.nextLine();
			Socio s = bd.obtenerSocio(id);
			bd.guardar();
			if (s != null) {
				if (s.getFechaSancion() == null || s.getFechaSancion().getTime() <= (new Date()).getTime()) {
					System.out.println("No esta sancionado");
					if (bd.obtenerLibrosPrestados(id) <= 2) {
						System.out.println("Tiene menos de dos o dos libros para devolver");
						mostrarLibros();
						System.out.println("Introduce el id del libro que quieres coger prestado: ");
						String isbn = sc.nextLine();
						Libro l = bd.obtenerLibro(isbn);
						if (l != null) {
							System.out.println("libro encontrado");
							if (l.getNumEjemplares() >= 1) {
								Prestamo p = new Prestamo();
								long d = new Date().getTime();
								p.setClave(new PrestamoID());
								p.getClave().setFechape(formato.parse(String.valueOf(d)));
								p.setFechaDevolPrevista(new Date(new Date().getTime() + (15 * 24 * 60 * 60 * 1000)));
								p.getClave().setLibro(l);
								p.getClave().setSocio(s);
								if (bd.insertarPrestamo(p)) {
									System.out.println("Préstamo " + p.getClave().getLibro().getIsbn()
											+ " registrado al socio con deni" + p.getClave().getSocio().getNif());
								} else {
									System.out.println("Error al intentar insertar prestamo");
								}
							} else {
								System.out.println("No tiene ejemplares");
							}
						} else {
							System.out.println("No existe libro");
						}
					} else {
						System.out.println("Tiene mas de dos libros");
					}

				} else {
					System.out.println("Esta sancionado el socio");
				}
			} else {
				System.out.println("no eiste el socio");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

	private static void mostrarLibros() {
		ArrayList<Libro> lib = bd.obtenerLibros();
		for (Libro libro : lib) {
			System.out.println(libro);
		}
	}

	private static void mostrarSocios() {
		ArrayList<Socio> s = bd.obtenerSocios();
		for (Socio socio : s) {
			System.out.println(socio);
		}

	}
}
