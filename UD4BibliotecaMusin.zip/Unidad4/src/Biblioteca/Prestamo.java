
package Biblioteca;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Embedded;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table
public class Prestamo {
	@EmbeddedId
	private PrestamoID clave;
	@Column(nullable = false)
	private Date fechaDevolPrevista;
	@Column(nullable = true)
	private Date fechaDevolReal;

	public Prestamo() {

	}

	public Prestamo(Date fechaDevolPrevista, Date fechaDevolReal, PrestamoID clave) {
		this.fechaDevolPrevista = fechaDevolPrevista;
		this.fechaDevolReal = fechaDevolReal;
		this.clave = clave;
	}

	public Date getFechaDevolPrevista() {
		return fechaDevolPrevista;
	}

	public void setFechaDevolPrevista(Date fechaDevolPrevista) {
		this.fechaDevolPrevista = fechaDevolPrevista;
	}

	public Date getFechaDevolReal() {
		return fechaDevolReal;
	}

	public void setFechaDevolReal(Date fechaDevolReal) {
		this.fechaDevolReal = fechaDevolReal;
	}

	public PrestamoID getClave() {
		return clave;
	}

	public void setClave(PrestamoID clave) {
		this.clave = clave;
	}

	@Override
	public String toString() {
		return "Prestamo [fechaPrestamo=" + clave.getFechape() + ", socioId=" + clave.getSocio().getId()
				+ ", libroIsbn=" + clave.getLibro().getIsbn() + ", fechaDevolPrevista=" + fechaDevolPrevista
				+ ", fechaDevolReal=" + fechaDevolReal + "]";
	}

}
