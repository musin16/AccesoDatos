package Examen;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.InsertOneResult;
import com.mongodb.client.result.UpdateResult;

public class Modelo {

	private MongoClient conexion = null;
	private MongoDatabase bd = null;

	public Modelo() {
		try {
			conexion = MongoClients.create("mongodb://localhost:27017");
			bd = conexion.getDatabase("ExamenT3");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public MongoClient getConexion() {
		return conexion;
	}

	public void setConexion(MongoClient conexion) {
		this.conexion = conexion;

	}

	public void cerrar() {
		try {
			conexion.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public Empleado buscarEmpleado(String dniIntro) {
		// TODO Auto-generated method stub
		Empleado resultado = null;
		try {
			MongoCollection<Document> col = bd.getCollection("Empleado");
			Bson filtro = Filters.eq("dni", dniIntro);
			Document d = col.find(filtro).first();

			if (d != null) {
				resultado = new Empleado();
				resultado.setDni(d.getString("dni"));
				resultado.setNombre(d.getString("nombre"));
				resultado.setDepartamento(d.getString("departamento"));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean crearEmpleado(Empleado emp) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("Empleado");
			InsertOneResult r = col.insertOne(new Document().append("dni", emp.getDni())
					.append("nombre", emp.getNombre()).append("departamento", emp.getDepartamento()));
			if (r.getInsertedId() != null) {
				resultado = true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public ArrayList<Destinatario> obtenerDestinatarios(String depIntro) {
		// TODO Auto-generated method stub
		ArrayList<Destinatario> resultado = new ArrayList<Destinatario>();
		try {
			MongoCollection<Document> col = bd.getCollection("Empleado");
			Bson filtro = Filters.eq("departamento", depIntro);
			MongoCursor<Document> destinatarios = col.find(filtro).iterator();

			while (destinatarios.hasNext()) {
				Document d = destinatarios.next();
				Destinatario des = new Destinatario();
				des.setEmpleado(d.getString("dni"));
				des.setLeido(true);
				resultado.add(des);

			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public int obtenerUltimoIdMensaje() {
		// TODO Auto-generated method stub
		int resultado = 0;

		try {
			MongoCollection<Document> col = bd.getCollection("Mensaje");
			Document r = col.aggregate(Arrays.asList(Aggregates.group(null, Accumulators.max("ultimo", "$codigo"))))
					.first();
			if (r != null) {
				System.out.println(r);
				resultado = r.getInteger("ultimo", 0);
				System.out.println(resultado);
			}
			resultado = resultado + 1;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return resultado;
	}

	public boolean insertarMensaje(Mensaje m) {
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("Mensaje");

			// Convertir la fecha a un formato compatible con MongoDB
			Date fecha = m.getFecha();
			SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");
			String fechaMongoDB = formatoFecha.format(fecha);

			ArrayList<Document> destinatariosDoc = new ArrayList<>();

			for (Destinatario d : m.getDestinatarios()) {

				Document destinatario = new Document().append("empleado", d.getEmpleado()).append("leido", d.isLeido());
				destinatariosDoc.add(destinatario);
			}

			InsertOneResult r = col.insertOne(new Document().append("codigo", m.getCodigo())
					.append("deEmpleado", m.getDeEmpleado()).append("paraDepartamento", m.getParaDepartamento())
					.append("fecha", fechaMongoDB).append("asunto", m.getAsunto()).append("mensaje", m.getMensaje())
					.append("destinatarios", destinatariosDoc));

			if (r.getInsertedId() != null) {
				resultado = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultado;
	}

	public ArrayList<Mensaje> obtenerMensajes(Empleado user) {
		// TODO Auto-generated method stub
		ArrayList<Mensaje> resultado = new ArrayList<>();
		try {
			MongoCollection<Document> col = bd.getCollection("Mensaje");

			Bson filtro = Filters.eq("destinatarios.empleado", user.getDni());
			Bson campos = Projections.fields(Projections.excludeId());

			MongoCursor<Document> r = col.aggregate(Arrays.asList(Aggregates.match(filtro),
					Aggregates.unwind("$destinatarios"), Aggregates.match(filtro), Aggregates.project(campos)))
					.iterator();

			while (r.hasNext()) {
				Document doc = r.next();
				Mensaje m = new Mensaje();
				m.setCodigo(doc.getInteger("codigo", 0));
				m.setDeEmpleado(doc.getString("deEmpleado"));
				Document d = (Document) doc.get("destinatarios");
				m.getDestinatarios().add(new Destinatario(d.getString("empleado"), d.getBoolean("leido", true)));
				resultado.add(m);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean borrarMensajesEmpleado(Empleado user) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("Mensaje");

			Bson filtro = Filters.eq("destinatarios.empleado", user.getDni());
			Bson modif = Updates.pull("destinatarios", new Document().append("empleado", user.getDni()));

			UpdateResult r = col.updateOne(filtro, modif);
			if (r.getModifiedCount() >= 1) {
				resultado = true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return resultado;
	}

	public ArrayList<Object[]> obtenerEstadistica(Empleado user) {
		// TODO Auto-generated method stub
		ArrayList<Object[]> resultado = new ArrayList<>();
		try {
			MongoCollection<Document> col = bd.getCollection("Mensaje");

			MongoCursor<Document> r = col.aggregate(Arrays.asList(
					Aggregates.match(Filters.eq("deEmpleado", user.getDni())),
					Aggregates.group("$destinatarios.empleado", Accumulators.sum("count", 1),
							Accumulators.max("fechaUltimo", "$fecha"), Accumulators.min("fechaPrimero", "$fecha"),
							Accumulators.first("departamento", "$paraDepartamento"))))
					.iterator();

			while (r.hasNext()) {
				Document d = r.next();

				Object[] obj = { d.getString("departamento"), d.getInteger("count"), d.getString("fechaUltimo"),
						d.getString("fechaPrimero") };
				resultado.add(obj);
			}

			// System.out.println(r.toJson());

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

}
