package Examen;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Clase3 {
	@Id
	private int id;

	public Clase3() {

	}
}
