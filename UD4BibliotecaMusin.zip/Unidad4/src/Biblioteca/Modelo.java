package Biblioteca;

import java.util.ArrayList;
import java.util.Date;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Modelo {
	private EntityManager conexion = null;

	public Modelo() {
		try {
			conexion = Persistence.createEntityManagerFactory("Biblioteca").createEntityManager();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public EntityManager getConexion() {
		return conexion;
	}

	public void setConexion(EntityManager conexion) {
		this.conexion = conexion;
	}

	public void cerrar() {
		try {
			conexion.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public ArrayList<Socio> obtenerSocios() {
		try {
			Query q = conexion.createQuery("FROM Socio", Socio.class);
			return (ArrayList<Socio>) q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ArrayList<Socio>();
	}

	public Socio obtenerSocio(int id) {
		try {
			return conexion.find(Socio.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public int obtenerLibrosPrestados(int id) {
		try {
			Query q = conexion.createQuery(
					"select COUNT(*) from Prestamo p where p.fechaDevolPrevista > current_date()  AND  p.clave.socio.id=?1");
			q.setParameter(1, id);
			return ((Number) q.getSingleResult()).intValue();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

	public ArrayList<Libro> obtenerLibros() {
		try {
			Query q = conexion.createQuery("from Libro");
			return (ArrayList<Libro>) q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ArrayList<>();
	}

	public Libro obtenerLibro(String isbn) {
		try {
			return conexion.find(Libro.class, isbn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean insertarPrestamo(Prestamo p) {
		try {
			conexion.getTransaction().begin();
			conexion.persist(p);
			conexion.getTransaction().commit();
			conexion.clear();
			return true;
		} catch (Exception e) {
			if (conexion.getTransaction().isActive()) {
				conexion.getTransaction().rollback();
			}
			e.printStackTrace();
			return false;
		}
	}

	public Prestamo obtenerPrestamo(PrestamoID pd) {
		try {
			Query q = conexion.createQuery("From Prestamo WHERE clave.socio.id=?1 and clave.libro.id=?2");
			q.setParameter(1, pd.getSocio().getId());
			q.setParameter(2, pd.getLibro().getIsbn());
			return (Prestamo) q.getResultList().get(0);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void guardar() {
		try {
			conexion.getTransaction().begin();
			conexion.getTransaction().commit();
			conexion.clear();
		} catch (Exception e) {
			conexion.getTransaction().rollback();
			e.printStackTrace();
		}

	}

	public boolean devolverLibro(Prestamo pm, Socio s) {
		try {
			conexion.getTransaction().begin();
			pm.setFechaDevolReal(new Date());
			if (pm.getFechaDevolReal().getTime() <= pm.getFechaDevolPrevista().getTime()) {
				conexion.merge(pm);
				conexion.getTransaction().commit();
				conexion.clear();
				return true;
			} else {
				s = obtenerSocio(s.getId());
				s.setFechaSancion(new Date(new Date().getTime() + (15 * 24 * 60 * 60 * 1000)));
				conexion.merge(s);
				conexion.merge(pm);
				conexion.getTransaction().commit();
				conexion.clear();
				return true;
			}

		} catch (Exception e) {
			try {
				conexion.getTransaction().rollback();
			} catch (Exception e2) {
				e.printStackTrace();
			}

			e.printStackTrace();
		}
		return false;
	}

	public boolean borrarLibro(Libro l) {
		try {
			conexion.getTransaction().begin();
			Query q = conexion.createQuery("DELETE Libro Where isbn=?1");
			q.setParameter(1, l.getIsbn());
			if (q.executeUpdate() == 1) {
				conexion.getTransaction().commit();
				conexion.clear();
			} else {
				conexion.getTransaction().rollback();
			}

			return true;
		} catch (Exception e) {
			try {
				conexion.getTransaction().rollback();
			} catch (Exception e2) {
				e.printStackTrace();
			}

			e.printStackTrace();
		}
		return false;
	}

	public boolean borrarLibroPrestamo(Libro l) {
		try {
			conexion.getTransaction().begin();
			Query q = conexion.createQuery("DELETE Prestamo Where clave.libro.isbn=?1");
			q.setParameter(1, l.getIsbn());
			if (q.executeUpdate() >= 1) {
				q = conexion.createQuery("DELETE Libro Where isbn=?1");
				q.setParameter(1, l.getIsbn());
				if (q.executeUpdate() == 1) {
					conexion.getTransaction().commit();
					conexion.clear();
					return true;
				} else {
					conexion.getTransaction().rollback();
				}
			} else {
				conexion.getTransaction().rollback();
			}

		} catch (Exception e) {
			try {
				conexion.getTransaction().rollback();
			} catch (Exception e2) {
				e.printStackTrace();
			}

			e.printStackTrace();
		}
		return false;
	}

}
