import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Principal {

	public static Scanner t = new Scanner(System.in);
	public static Modelo bd = new Modelo();
	public static SimpleDateFormat formato = new SimpleDateFormat("ddMMyy");

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		if (bd.getConexion() != null) {
			int opcion = 0;
			do {
				System.out.println("Selecciona una opción");
				System.out.println("0-Salir");
				System.out.println("1-Crear Producto");
				System.out.println("2-Crear Factura");
				System.out.println("3-Anular Factura");
				System.out.println("4-Informe de facturación");
				opcion = t.nextInt();
				t.nextLine();
				switch (opcion) {
				case 1:
					crearProducto();
					break;
				case 2:
					crearFactura();
					break;
				case 3:
					anularFactura();
					break;
				case 4:
					informeFactura();
					break;

				}

			} while (opcion != 0);
		} else {
			System.out.println("Error de conexión");
		}
	}

	private static void informeFactura() {
		ArrayList<Object[]> valores = bd.obtenerInformeFactura();
		for (Object[] obj : valores) {
			System.out.println("Codigo : " + obj[0]);
			System.out.println("Nombre : " + obj[1]);
			System.out.println("Numero de venta : " + obj[2]);
			System.out.println("Cantidad de venta : " + obj[3]);
			System.out.println("Ingresos : " + obj[4]);
		}
	}

	private static void anularFactura() {
		mostrarFacturasActivas();
		System.out.println("Codigo factura");
		int codigo = t.nextInt();
		t.nextLine();
		Factura f = bd.obtenerFactura(codigo);
		if (f != null) {
			System.out.println("No esta anulada");
			f.setNumero(bd.ultimoCodigoF() + 1);
			for (Detalle d : f.getDetalle()) {
				d.setCantidad(d.getCantidad() * -1);
			}
			if (bd.crearFactura(f)) {
				System.out.println("Factura de anulacion creada correctamente");
				if (bd.actualizarStock(f.getDetalle())) {
					System.out.println("stock detalles actualizado");
					if (bd.anularFactura(codigo, f.getNumero())) {
						System.out.println("se ha facturado completamente");
					} else
						System.out.println("Error al anular facturacion");
				} else {
					System.out.println("Error al modificar factura");
				}

			} else
				System.out.println("Error al crear factura");
		} else {
			System.out.println("No existe factura");
		}
	}

	private static void mostrarFacturasActivas() {
		ArrayList<Factura> f = bd.obtenerFacturas();
		for (Factura factura : f) {
			System.out.println(factura);
		}

	}

	private static void crearFactura() {
		// TODO Auto-generated method stub
		Factura f = new Factura();
		f.setNumero(bd.ultimoCodigoF() + 1);
		f.setFecha(new Date());
		System.out.println("Dni Cliente");
		f.setCliente(t.nextLine());
		String mas = "0";
		do {
			mostrarProductos();
			Producto p = bd.obtenerProducto(t.nextLine());
			if (p != null) {
				Detalle d = new Detalle();
				d.setProducto(p.getCodigo());
				System.out.println("Cantidad");
				d.setCantidad(d.getCantidad() + t.nextInt());
				t.nextLine();
				if (d.getCantidad() > p.getStock()) {
					System.out.println("Error, no hay stock");
				} else {
					d.setPrecioUdad(p.getPrecio());
					f.getDetalle().add(d);
				}
			} else {
				System.out.println("Error, no existe producto");
			}
			System.out.println("Mas productos (1-Sí/*-No");
			mas = t.nextLine();
		} while (mas.equalsIgnoreCase("1"));
		if (!f.getDetalle().isEmpty()) {
			if (bd.crearFactura(f)) {
				if (bd.actualizarStock(f.getDetalle())) {
					System.out.println("Factura creada y stock actualizado");
				} else {
					System.out.println("Error al actualizar el stock");
				}
			} else {
				System.out.println("Error al crear la factura");
			}
		}
	}

	private static void mostrarProductos() {
		// TODO Auto-generated method stub
		ArrayList<Producto> productos = bd.obtenerProductos();
		for (Producto p : productos) {
			System.out.println(p);
		}
	}

	private static void crearProducto() {
		// TODO Auto-generated method stub
		System.out.println("Código");
		String codigo = t.nextLine();
		Producto p = bd.obtenerProducto(codigo);
		if (p == null) {
			p = new Producto();
			p.setCodigo(codigo);
			System.out.println("Nombre");
			p.setNombre(t.nextLine());
			System.out.println("Precio");
			p.setPrecio(t.nextFloat());
			t.nextLine();
			System.out.println("Stock");
			p.setStock(t.nextInt());
			t.nextLine();
			if (bd.crearProducto(p)) {
				System.out.println("Producto Creado");
			}
		} else {
			System.out.println("Producto ya existe");
		}
	}

}
