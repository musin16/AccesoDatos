package Examen;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Usuario {
	@Id
	private String nick;
	@Column(nullable = false)
	private String email;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "clave.usuario")
	List<Clase2> reproduciones = new ArrayList<>();

	public Usuario() {
	}

	
}
