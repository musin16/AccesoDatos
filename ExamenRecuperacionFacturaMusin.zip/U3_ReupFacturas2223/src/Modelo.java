import java.util.ArrayList;
import java.util.Arrays;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Field;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.InsertOneResult;
import com.mongodb.client.result.UpdateResult;
import static com.mongodb.client.model.Accumulators.*;
import static com.mongodb.client.model.Aggregates.*;
import static com.mongodb.client.model.Filters.*;
import static com.mongodb.client.model.Projections.*;

public class Modelo {
	private MongoClient conexion = null;
	private MongoDatabase bd = null;

	public Modelo() {
		try {
			conexion = MongoClients.create("mongodb://localhost:27017");
			bd = conexion.getDatabase("tienda");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public MongoClient getConexion() {
		return conexion;
	}

	public void setConexion(MongoClient conexion) {
		this.conexion = conexion;

	}

	public void cerrar() {
		try {
			conexion.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public Producto obtenerProducto(String codigo) {
		// TODO Auto-generated method stub
		Producto resultado = null;
		try {
			MongoCollection<Document> col = bd.getCollection("productos");
			Document r = col.find(eq("codigo", codigo)).first();
			if (r != null) {
				resultado = new Producto();
				resultado.setCodigo(r.getString("codigo"));
				resultado.setNombre(r.getString("nombre"));
				resultado.setPrecio(r.getDouble("precio"));
				resultado.setStock(r.getInteger("stock", 0));
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean crearProducto(Producto p) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("productos");
			InsertOneResult r = col.insertOne(new Document().append("codigo", p.getCodigo())
					.append("nombre", p.getNombre()).append("precio", p.getPrecio()).append("stock", p.getStock()));
			if (r.getInsertedId() != null) {
				resultado = true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public int ultimoCodigoF() {
		// TODO Auto-generated method stub
		int resultado = 0;
		try {
			MongoCollection<Document> col = bd.getCollection("facturas");

			Document r = col.aggregate(Arrays.asList(group(null, max("numero", "$numero")))).first();
			if (r != null) {
				resultado = r.getInteger("numero", 0);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public ArrayList<Producto> obtenerProductos() {
		// TODO Auto-generated method stub
		ArrayList<Producto> resultado = new ArrayList();
		try {
			MongoCollection<Document> col = bd.getCollection("productos");

			MongoCursor<Document> r = col.find().iterator();
			while (r.hasNext()) {
				Document d = r.next();
				Producto p = new Producto();
				p.setCodigo(d.getString("codigo"));
				p.setNombre(d.getString("nombre"));
				p.setPrecio(d.getDouble("precio"));
				p.setStock(d.getInteger("stock", 0));
				resultado.add(p);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean crearFactura(Factura f) {
		// TODO Auto-generated method stub
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("facturas");

			ArrayList<Document> detalle = new ArrayList();
			for (Detalle d : f.getDetalle()) {
				Document doc = new Document().append("producto", d.getProducto()).append("cantidad", d.getCantidad())
						.append("precioUnidad", d.getPrecioUdad());
				detalle.add(doc);
			}

			InsertOneResult r = col.insertOne(new Document().append("numero", f.getNumero())
					.append("fecha", f.getFecha()).append("cliente", f.getCliente()).append("detalle", detalle)
					.append("facturaAnulacion", 0));
			if (r.getInsertedId() != null) {
				resultado = true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean actualizarStock(ArrayList<Detalle> detalle) {
		// TODO Auto-generated method stub
		boolean resultado = true;
		try {
			MongoCollection<Document> col = bd.getCollection("productos");

			for (Detalle d : detalle) {
				Bson filtro = eq("codigo", d.getProducto());
				Bson modif = Updates.inc("stock", d.getCantidad() * -1);

				UpdateResult r = col.updateOne(filtro, modif);
				if (r.getModifiedCount() != 1) {
					resultado = false;
				}
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public ArrayList<Factura> obtenerFacturas() {
		ArrayList<Factura> resultado = new ArrayList();
		try {
			MongoCollection<Document> col = bd.getCollection("facturas");
			Bson filtro = eq("facturaAnulacion", 0);
			MongoCursor<Document> r = col.find(filtro).iterator();
			while (r.hasNext()) {
				Document d = r.next();
				Factura p = new Factura();
				p.setCliente(d.getString("cliente"));
				p.setNumero(d.getInteger("numero", 0));
				p.setFacturaAnulacion(d.getInteger("facturaAnulacion", 0));
				ArrayList<Document> docs = (ArrayList<Document>) d.get("detalle");
				double facTotal = 0;
				for (Document doc : docs) {
					Detalle de = new Detalle(doc.getString("producto"), doc.getInteger("cantidad"),
							doc.getDouble("precioUnidad"));
					p.getDetalle().add(de);

					facTotal += de.getCantidad() * de.getPrecioUdad();
				}
				p.total = facTotal;

				resultado.add(p);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public Factura obtenerFactura(int codigo) {
		Factura resultado = new Factura();
		try {
			MongoCollection<Document> col = bd.getCollection("facturas");
			Bson filtro = and(eq("numero", codigo), eq("facturaAnulacion", 0));
			MongoCursor<Document> r = col.find(filtro).iterator();
			while (r.hasNext()) {
				Document d = r.next();
				Factura p = new Factura();
				p.setCliente(d.getString("cliente"));
				p.setNumero(d.getInteger("numero", 0));
				p.setFacturaAnulacion(d.getInteger("facturaAnulacion", 0));
				ArrayList<Document> docs = (ArrayList<Document>) d.get("detalle");
				for (Document doc : docs) {
					Detalle de = new Detalle(doc.getString("producto"), doc.getInteger("cantidad"),
							doc.getDouble("precioUnidad"));
					p.getDetalle().add(de);
				}
				resultado = p;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return resultado;
	}

	public boolean anularFactura(int codigo, int anulada) {
		boolean resultado = false;
		try {
			MongoCollection<Document> col = bd.getCollection("facturas");
			Bson filtro = eq("numero", codigo);
			Bson modif = Updates.set("facturaAnulacion", anulada);
			UpdateResult res = col.updateOne(filtro, modif);
			if (res.getModifiedCount() == 1) {
				resultado = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultado;
	}

	public ArrayList<Object[]> obtenerInformeFactura() {
		ArrayList<Object[]> obj = new ArrayList<>();
		MongoCollection<Document> col = bd.getCollection("facturas");
		MongoCursor<Document> cursor = col
				.aggregate(
						Arrays.asList(unwind("$detalle"),
								group("$detalle.producto", sum("total", "$detalle.cantidad"), sum("cont", 1),
										sum("importe", new Document("$sum",
												new Document("$multiply",
														Arrays.asList("$detalle.cantidad", "$detalle.precioUnidad"))))),
								lookup("productos", "_id", "codigo", "productos")))
				.iterator();

		while (cursor.hasNext()) {
			Document r = cursor.next();
			ArrayList<Document> productos = (ArrayList<Document>) r.get("productos");
			Document producto = productos.get(0);
			String nombre = producto.getString("nombre");
			String codigo = producto.getString("codigo");
			int ventas = r.getInteger("cont");
			int cantidad = r.getInteger("total");
			double importe = r.getDouble("importe");
			Object[] o = { codigo, nombre, ventas, cantidad, importe };
			obj.add(o);
		}

		return obj;
	}

}
