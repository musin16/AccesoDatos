package Examen;

public class Clave {
	public Clave() {
		// TODO Auto-generated constructor stub
	}
}
