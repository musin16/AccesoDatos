package Examen;

import java.util.ArrayList;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

public class Modelo {
	private EntityManager conexion = null;

	public Modelo() {
		try {
			conexion = Persistence.createEntityManagerFactory("hbaa").createEntityManager();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public EntityManager getConexion() {
		return conexion;
	}

	public void setConexion(EntityManager conexion) {
		this.conexion = conexion;
	}

	public void cerrar() {
		try {
			conexion.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

	public Usuario obtenerUsuario(String id) {
		try {
			return conexion.find(Usuario.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public ArrayList<Object> obtener() {
		try {
			Query q = conexion.createQuery("FROM Tabla");
			return (ArrayList<Object>) q.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public Object obtenerUn(int id) {
		try {
			return conexion.find(Clase1.class, id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public void guardar() {
		try {
			conexion.getTransaction().begin();
			conexion.getTransaction().commit();
			conexion.clear();
		} catch (Exception e) {
			conexion.getTransaction().rollback();
			e.printStackTrace();
		}

	}

	public void insert(Object obj) {
		try {
			conexion.getTransaction().begin();
			conexion.persist(obj);
			conexion.getTransaction().commit();
			conexion.clear();
		} catch (Exception e) {
			conexion.getTransaction().rollback();
			e.printStackTrace();
		}

	}

	public void actualizar(Clase1 obj) {
		try {
			conexion.getTransaction().begin();
			Query q = conexion.createQuery("Update Clase1 SET datos=?1  Where id=?1");
			q.setParameter(1, obj.getId());
			conexion.getTransaction().commit();
			conexion.clear();
		} catch (Exception e) {
			conexion.getTransaction().rollback();
			e.printStackTrace();
		}

	}

}