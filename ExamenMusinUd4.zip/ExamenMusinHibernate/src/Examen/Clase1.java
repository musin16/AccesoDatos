package Examen;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table
public class Clase1 {
	@Id
	private int id;
	@Column(nullable = false)
	private String nombre;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "clave.libro")
	private List<Clase2> clases = new ArrayList<>();

	public Clase1() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
